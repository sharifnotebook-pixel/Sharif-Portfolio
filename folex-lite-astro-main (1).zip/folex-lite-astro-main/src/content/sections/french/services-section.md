---
enable: true
title: "Ce que nous pouvons faire pour nos clients"
# sectionDirection: "horizontal" # horizontal | vertical

options:
  layout: "accordion" # accordion | grid
  limit: 6 # false / number
  column: 3 # 1 / 2 / 3 - applicable uniquement si layout est "grid"
  iconPlacement: "top" # top / right - applicable uniquement si layout est "grid"
---
