---
enable: true # Control the visibility of this section across all pages where it is used
title: "Lisez nos articles et actualit s"

options:
  layout: "grid" # grid | overlay | horizontal
  limit: 3
---
