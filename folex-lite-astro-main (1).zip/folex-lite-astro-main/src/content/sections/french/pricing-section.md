---
enable: true # Contrôle la visibilité de cette section sur toutes les pages où elle est utilisée
title: ""

list:
  - enable: true
    name: "Personnel"
    description: "Nous nous soucions de leur réussite. Pour nous, les relations authentiques sont vraies"
    price:
      prependValue: "€"
      value: "180"
      appendValue: "/mois"
    features:
      - WEB & MOBILE
      - DOMAINE PERSONNALISÉ GRATUIT
      - MEILLEUR HÉBERGEMENT
      - SUPPORT EXCEPTIONNEL
      - DESIGN WEB
    button:
      # Refer to the `sharedButton` schema in `src/sections.schema.ts` for all available configuration options (e.g., enable, label, url, hoverEffect, variant, icon, tag, rel, class, target, etc.)
      enable: true
      label: "CHOISIR CE PLAN"
      url: "/"
      # hoverEffect: "" # Optional: text-flip | creative-fill | magnetic | magnetic-text-flip
      # variant: "" # Optional: fill | outline | text | circle
      # rel: "" # Optional
      # target: "" # Optional
  - enable: true
    name: "Startup"
    description: "Nous nous soucions de leur réussite. Pour nous, les relations authentiques sont vraies"
    price:
      prependValue: "€"
      value: "180"
      appendValue: "/mois"
    features:
      - WEB & MOBILE
      - DOMAINE PERSONNALISÉ GRATUIT
      - MEILLEUR HÉBERGEMENT
      - SUPPORT EXCEPTIONNEL
      - DESIGN WEB
    button:
      # Refer to the `sharedButton` schema in `src/sections.schema.ts` for all available configuration options (e.g., enable, label, url, hoverEffect, variant, icon, tag, rel, class, target, etc.)
      enable: true
      label: "CHOISIR CE PLAN"
      url: "/"
      # hoverEffect: "" # Optional: text-flip | creative-fill | magnetic | magnetic-text-flip
      # variant: "" # Optional: fill | outline | text | circle
      # rel: "" # Optional
      # target: "" # Optional
  - enable: true
    name: "Entreprise"
    description: "Nous nous soucions de leur réussite. Pour nous, les relations authentiques sont vraies"
    price:
      prependValue: "€"
      value: "180"
      appendValue: "/mois"
    features:
      - WEB & MOBILE
      - DOMAINE PERSONNALISÉ GRATUIT
      - MEILLEUR HÉBERGEMENT
      - SUPPORT EXCEPTIONNEL
      - DESIGN WEB
    button:
      # Refer to the `sharedButton` schema in `src/sections.schema.ts` for all available configuration options (e.g., enable, label, url, hoverEffect, variant, icon, tag, rel, class, target, etc.)
      enable: true
      label: "CHOISIR CE PLAN"
      url: "/"
      # hoverEffect: "" # Optional: text-flip | creative-fill | magnetic | magnetic-text-flip
      # variant: "" # Optional: fill | outline | text | circle
      # rel: "" # Optional
      # target: "" # Optional
---
