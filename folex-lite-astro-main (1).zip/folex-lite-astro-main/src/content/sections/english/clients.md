---
enable: true # Control the visibility of this section across all pages where it is used
title: ""

list:
  - alt: "example alt text"
    src: "/images/clients/1.svg"
  - alt: "example alt text"
    src: "/images/clients/2.svg"
  - alt: "example alt text"
    src: "/images/clients/3.svg"
  - alt: "example alt text"
    src: "/images/clients/4.svg"
  - alt: "example alt text"
    src: "/images/clients/5.svg"
  - alt: "example alt text"
    src: "/images/clients/6.svg"
  - alt: "example alt text"
    src: "/images/clients/1.svg"
  - alt: "example alt text"
    src: "/images/clients/2.svg"

options:
  appearance: "light" # light / dark
  columnsPerRow: 4 # 4 / 6 (default - 4)
---
