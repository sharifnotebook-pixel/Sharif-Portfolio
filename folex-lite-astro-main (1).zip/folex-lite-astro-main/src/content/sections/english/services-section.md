---
enable: true
title: "What We Can Do for Our Clients"
# sectionDirection: "horizontal" # horizontal | vertical

options:
  layout: "accordion" # accordion | grid
  limit: 6 # false / number
  column: 3 # 1 / 2 / 3 - applicable only if layout is "grid"
  iconPlacement: "top" # top / right - applicable only if layout is "grid"
---
