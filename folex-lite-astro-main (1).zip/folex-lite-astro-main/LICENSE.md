Getastrothemes Free Theme License
Copyright (c) 2025 Getastrothemes

Permission is hereby granted to use this theme (the “Theme”) in personal or commercial projects, under the following conditions:

1. Attribution (Optional)
   Attribution is appreciated but not required. You may include a visible link to getastrothemes.com in your site footer or credits section.
2. No Redistribution or Resale
   You may not sublicense, redistribute, resell, or repackage this Theme — modified or unmodified — on any marketplace, theme directory, or personal website.
3. Modification Permitted
   You may modify this Theme for your own use. However, the modified version remains subject to this license and may not be redistributed or sold.
4. Disclaimer
   This Theme is provided “as is”, without any warranty. The author is not liable for any damages or issues arising from its use.

By using this Theme, you agree to the terms of this license.
